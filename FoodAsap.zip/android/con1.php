<?php

$con = mysqli_connect("localhost","root", "","boma");
//$con1 = mysqli_connect("localhost","root", "","boma");
if (!$con)
{
	echo "error!";
}

?>